# CSC 361 Assignment 2

## Usage
    Run the code with ``` python3 analze_trace.py <filename.cap> ```


## Other
```test.sh``` compares with the output file of analyze trace with the example output provided in Brightspace.