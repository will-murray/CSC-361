# Running this code

To run Webtester.py use the following command:

```python3 WebTester.py <uri>```